from __future__ import annotations
# Package marker for app.models
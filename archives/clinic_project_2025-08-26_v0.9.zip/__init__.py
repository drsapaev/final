# Package marker for app.api.v1
from __future__ import annotations
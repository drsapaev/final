from __future__ import annotations

from .config import Settings, settings

__all__ = ["Settings", "settings"]